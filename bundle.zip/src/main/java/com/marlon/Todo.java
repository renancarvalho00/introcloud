package com.marlon;

public class Todo {

  public int id;

  public String name;

  public Todo(final int id, final String name) {
    this.id = id;
    this.name = name;
  }
}